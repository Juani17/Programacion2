package punto3;

import java.util.Scanner;
import java.util.InputMismatchException;

public class CalculoAreaTriangulo {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double base = 0;
        double altura = 0;
        boolean entradaValida = false;

        // Lectura de la base
        while (!entradaValida) {
            System.out.print("Introduce la base del triángulo: ");
            try {
                base = Double.parseDouble(sc.nextLine().trim());
                if (base <= 0) {
                    System.out.println("La base debe ser un número positivo.");
                } else {
                    entradaValida = true;
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada no válida. Por favor, introduce un número.");
            }
        }

        entradaValida = false;

        // Lectura de la altura
        while (!entradaValida) {
            System.out.print("Introduce la altura del triángulo: ");
            try {
                altura = Double.parseDouble(sc.nextLine().trim());
                if (altura <= 0) {
                    System.out.println("La altura debe ser un número positivo.");
                } else {
                    entradaValida = true;
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada no válida. Por favor, introduce un número.");
            }
        }

        // Cálculo del área
        double area = (base * altura) / 2;
        System.out.printf("El área del triángulo es: %.2f\n", area);
    }
}
