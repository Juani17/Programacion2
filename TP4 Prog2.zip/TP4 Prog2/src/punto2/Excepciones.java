package punto2;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Excepciones {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        double n = 0;
        int posicion = -1;
        String cadena;
        double[] valores = {9.83, 4.5, -3.06, 0.06, 2.52, -11.3, 7.60, 3.00, -30.4, 105.2};

        System.out.println("Contenido del array antes de modificar:");
        for (int i = 0; i < valores.length; i++) {
            System.out.printf("%.2f ", valores[i]);
        }

        System.out.print("\n\nIntroduce la posición del array a modificar: ");
        try {
            cadena = sc.nextLine();
            posicion = Integer.parseInt(cadena);

            if (posicion < 0 || posicion >= valores.length) {
                throw new ArrayIndexOutOfBoundsException("Posición fuera de los límites del array");
            }

            System.out.print("\nIntroduce el nuevo valor de la posición " + posicion + ": ");
            n = sc.nextDouble();

            valores[posicion] = n;

            System.out.println("\nPosición a modificar: " + posicion);
            System.out.println("Nuevo valor: " + n);

        } catch (NumberFormatException e) {
            System.out.println("Error: La entrada para la posición no es un número válido.");
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (InputMismatchException e) {
            System.out.println("Error: La entrada para el nuevo valor no es un número válido.");
        } catch (Exception e) {
            System.out.println("Error inesperado: " + e.getMessage());
        }

        System.out.println("\nContenido del array modificado:");
        for (int i = 0; i < valores.length; i++) {
            System.out.printf("%.2f ", valores[i]);
        }
    }
}
