//Escribe un programa que juegue con el usuario a adivinar un número. El ordenador debe generar un número entre 1 y 100,
//y el usuario tiene que intentar adivinarlo. Para ello, cada vez que el usuario introduce un valor, el ordenador
//debe decirle al usuario si el número que tiene  que adivinar es mayor o menor que el que ha introducido el
//usuario. Cuando consiga adivinarlo, debe indicárselo e imprimir en pantalla el número de veces que el usuario ha
//intentado adivinar el número. Si el usuario introduce algo que no es un número, debe indicarlo en pantalla, y
//contarlo como un intento.

import java.util.Random;
import java.util.Scanner;

public class Adivinarnumero {
    public static void main(String[] args) {
        Random random = new Random();
        int numeroAdivinar = random.nextInt(100) + 1; // Genera un número entre 1 y 100
        Scanner scanner = new Scanner(System.in);
        int intentos = 0;
        boolean adivinado = false;

        System.out.println("¡Bienvenido al juego de adivinar el número!");
        System.out.println("He escogido un número entre 1 y 100. Intenta adivinarlo.");

        while (!adivinado) {
            System.out.print("Introduce tu número: ");
            String entrada = scanner.nextLine();
            intentos++;

            try {
                int numeroUsuario = Integer.parseInt(entrada);

                if (numeroUsuario < 1 || numeroUsuario > 100) {
                    System.out.println("Por favor, introduce un número entre 1 y 100.");
                } else if (numeroUsuario < numeroAdivinar) {
                    System.out.println("El número es mayor.");
                } else if (numeroUsuario > numeroAdivinar) {
                    System.out.println("El número es menor.");
                } else {
                    System.out.println("adivinaste el número en " + intentos + " intentos.");
                    adivinado = true;
                }
            } catch (NumberFormatException e) {
                System.out.println("Eso no es un número válido. Por favor, introduce un número entre 1 y 100.");
            }
        }

        scanner.close();
    }
}
